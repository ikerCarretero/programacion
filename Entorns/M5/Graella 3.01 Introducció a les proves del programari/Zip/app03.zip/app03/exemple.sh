echo "11 40" | ./llista-senars5
