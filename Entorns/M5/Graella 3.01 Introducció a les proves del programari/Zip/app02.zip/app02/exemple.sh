echo "912345678" | ./telephon-number2.out
