echo "912345678" | ./telephon-number1.out
