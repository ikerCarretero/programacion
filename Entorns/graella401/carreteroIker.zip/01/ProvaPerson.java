
public class ProvaPerson {

    public static void main(String[] args) {
        Person p = new Person("Nom de la Persona",25);
        p.print();
    }
}
