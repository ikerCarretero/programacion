public class Calculator {
    public void calculate() {
        int a = 5;
        int b = 10;
        int sum = a + b;
        int product = a * b;
        System.out.println("Sum: " + sum);
        System.out.println("Product: " + product);
    }
}
